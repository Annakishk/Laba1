/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package books;


public class RusFic extends Books{
    public RusFic(String CompleteName) {
        super(CompleteName);                    // вызов конструктора суперкласса, т.е. берём данные из родительского класса
    } 

   
}
